# Autor
# Version
# 
print("Hola Mundo")
print("Adios") #equivalente a echo#
nombre=input("Dime tu nombre: ") #variable nombre/ indica como se imprime el valor de una variable#
print(nombre) #Indica el otro añadido a la variable#

n=float(input("Dame el prime valor:"))
m=float(input("Dame el segundo valor:"))
suma=n+m
print(suma)

n=int(input("Dame el prime valor:"))
m=int(input("Dame el segundo valor:"))
suma=n+m
print(suma)

print("Hola",nombre,"que tal estas")
print(f"Hola {nombre} que tal estas")
